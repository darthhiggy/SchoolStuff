
public class Goblin extends Monster
{
	public Goblin()
	{
		super();
		setPenalty(2);
		setBonus(-1);
	}
}
