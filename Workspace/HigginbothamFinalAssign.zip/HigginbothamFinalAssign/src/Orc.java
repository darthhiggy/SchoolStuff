
public class Orc extends Monster 
{
	public Orc()
	{
		super();
		setPenalty(1);
	}
}
