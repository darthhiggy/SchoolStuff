
public class Dragon extends Monster
{
	public Dragon()
	{
		super();
		setPenalty(-1);
		setBonus(2);
	}
}
